TEAM MEMBERS AND RESPONSIBILITIES:

Who your Team Members are:
1. Antony Loose     [aloo0008@student.monash.edu] 
2. Eric Chen        [eche0034@student.monash.edu]
3. Max Ramm         [mram0034@student.monash.edu]
4. Mursal Ashraf    [mash0019@student.monash.edu]
5. Suryadeep Singh  [ssin0061@student.monash.edu]

How you Should contact them?
Means of communication:
- Slack
- Messenger
- Emails

We are Majorly using slack for communication between team Members, but for convinience we are using messenger. The team also sometimes communicates and shares files using email.

Roles and Responsibilites:

The roles have not been fixed yet:
1. Antony Loose: Stats widget 
2. Eric Chen: CSS 
3. Max Ramm: League Table
4. Mursal Ashraf: App Navigation (tab bar etc.) CSS
5. Suryadeep Singh: Live match widget

Responsibilites of a Team member:
1. Working and cooperating along with team members
2. Assigning and taking in responsibilites.
3. Communicate with team members.
4. If stuck on a task should ask for teammates help rather than not 
doing it.
5. Timely deliver the allocated tasks so that the team is not lagging behind.
6. Attend meetings, if the teammate cannot attend meetings, the person should inform the team before hand.


