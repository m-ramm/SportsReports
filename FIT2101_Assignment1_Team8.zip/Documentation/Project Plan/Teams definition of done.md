# Teams definition of done
MVP - minimum viable product: The team has finished the MVP when there is one sport with three leagues and there are two widgets for each league, these widgets can be two of, league table, player statistics or live matches. The MVP will also have a landing page with the company logo. \
Expected product: The team is expected to complete 2-3 sports with at least 3 leagues per sport and a total of three widgets. The navigation and aesthetic of page should be well designed and user friendly.

The teams definition 'done' is when each feature meets its corresponding acceptance criteria and passes all relevant unit tests. Ensure high coverage (90%+) of the codebase when writing unit tests (so that all code is tested thoroughly).