# How we will allocate tasks
Each team member will be assigned part of the UI to design. \
Antony: Stats widget \
Suryadeep: Live match widget \
Max: League table widget \
Eric: CSS \
Mursal: App navigation (tab bar etc.)/CSS \

Tasks will be allocated every Wednesday after the workshop during our team meeting. Tasks will be allocated based on skills and abilities, note that even though a task may be allocated to one person, other team members may also decide to help.