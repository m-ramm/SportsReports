**Team Process Model:**

*Features of scrum that the team will be doing:*

1. Product Backlog: The team will be creating a list of product backlog Items, these items would be broken down simplified tasks that would help achive the bigger project. Our product Backlog aims to contain:
    - Detailed backlog items, sorted by priority. The team will be working on high priority items first.

    - Estimated time to complete one sprint will usually be a week this is because of how the unit is designed.

    - Emergent- If the backlog items change or reshuffle, the team will reprioritize according to new changes.

2. Sprint Planning: The team would be having Sprint Planning session in 2 parts, the first half will be about:  
    - User stories and Product backlog would be broken down into smaller and more detailed tasks.

    the second half would be about:
    - Deciding the set of tasks that the team needs to complete and allocation of these tasks to team members.

3. Product Reviews and Retrospectives:
    Product Review: Prepare a demo presentation on the current status of the product.

    - Product Review would probably done in week 8 or week 9, before
    the mid semester break starts. Hence we might have only one product review and one finalized product presentation.

    Retrospective: The team is going to conduct a retrospective of the project after every sprint so that the team pace can be known and team members capailities can be used to a higher extent.

4. Backlog Refinement: Backlog refinement will be done by the team before beggining of a new sprint and team will explain theses tasks to the Product Owner and try to come up with some estimate that how much time it will take to complete these tasks. Also discussing what is feasable to achieve and what is not.  

*Features of Scrum that the team will not be doing:*

1. The Daily Scrum: The daily scrum is 15 minute meeting at the start of each day. Instead of doing a Daily Scrum, the team will
be doing a weekly scrum, in which we will divide the weekly scrum 
into 3 parts:

- What did the team members do last week?

- What does the team members plan to do next week?

- What is preventing a team member to complete a certain task next week?

2. Story Points, Velocity and Burndown: Although it is very important to know about these terms for each member but:

- for the following project we dont really need to built story
points, Velocity and Burndown as its not feasable in the given time.



    