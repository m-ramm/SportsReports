## User stories
### 1
As a user, I want to be able to select a sport so that I can see  more information like fixtures etc.about the selected sport \
### 2
As a user I want to be able to view the entire league table. \
### 3
As a user I want to be able to select a team so that I can view their match history \
Acceptance criteria: 
### 4
As a user I want to be able select a player and a statistic and view a graph of the stat selected vs games played \
Acceptance criteria: 
### 5
As a user I want to be able to select a match and see a line graph of the match history \
Acceptance criteria: 
### 6
As a user I want to be able to see key events in the match \
Acceptance criteria:
### 7
As a user I want to be able to view the location and time of the match in progress  
Acceptance criteria: 
### 8
As a user, I want to be able to see teams upcoming matches so that I am updated.
Acceptance criteria:  
### 9
As a user, I want to be able to see individual player stats so that I can be updated.
This story will be done when,

### 10
As a user, I want to see recent game scores / stats, in case I missed a game.
This story will be done when,

### 11
As a user, I want to change the mode of the app from light to dark and vice versa in the settings for convenience.
This story will be done when,
### 12
As a user, I want to change my favourite team in the settings page, in case my preference changes.
This story will be done when,
