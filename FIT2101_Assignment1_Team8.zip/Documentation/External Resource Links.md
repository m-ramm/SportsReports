# External Resources  
<a href="https://docs.google.com/document/d/1G8h-Qv4JCg-ZJiDMxLaUW6sdRuQFSV8IWYjJHN3vPHI/edit#">Product Backlog / Sprint 1 Goal and Retrospective</a>  
<a href="https://docs.google.com/spreadsheets/d/1-LTINpJ2GDVRR0Hwj1f8zjIifspsaaQ8OYLVjhbZQeU/edit#gid=0">Time Sheet</a>  
<a href="https://lucid.app/lucidspark/22c5e2e0-c940-4f68-b82c-de814b67822a/edit?referringApp=slack&shared=true#">User Story Planning</a>