function showHideRow(row) 
    {
        $("#" + row).toggle();
    }